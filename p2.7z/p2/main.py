name="Lomanov"
userName="Lomanov"
user_name="Lomanov"

#две разные переменные
name = "Lomanov"
Name = "Lomanov"
name = "Lomanov" # определение переменной name
print(name) #вывод значения переменной name на консоль
name="Lomanov" #переменной name равна "Lomanov"
print(name) #выводит: Lomanov
name= "Nikita" #меняем значение на "Nikita"
print(name) #выводит: Nikita


myAge=input("Введите свой возраст")
print("Ваш возраст",myAge)


isGood=True
print(isGood)   #True

isAlive=False
print(isAlive)

myAge=22
print("Возраст",myAge) #Возраст: 22

myCount=76
print("Количество:",myCount) #Количество: 76




myNumberOne=0b11
myNubmerTwo=0b1011
myNubberThree=0b10001
print(myNumberOne) #3 в десятичной системе
print(myNumberTwo) #11 в десятичной системе
print(myNumberThree) #33 в десятичной системе


